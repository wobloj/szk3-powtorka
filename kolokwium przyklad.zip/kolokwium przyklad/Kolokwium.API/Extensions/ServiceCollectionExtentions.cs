﻿using Kolokwium.API.Services;

namespace Kolokwium.API.Extensions
{
    public static class ServiceCollectionExtentions
    {
        public static IServiceCollection AddCompanyServices(this IServiceCollection services)
        {
            services.AddTransient<CompanyServices>();
            services.AddDbContext<CompanyDbContext, CompanyDbContext>();
            return services;
        }
    }
}
