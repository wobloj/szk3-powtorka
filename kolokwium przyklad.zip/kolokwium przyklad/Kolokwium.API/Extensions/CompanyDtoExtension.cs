﻿using Kolokwium.API.Dto;
using System.Runtime.CompilerServices;

namespace Kolokwium.API.Extensions
{
    public static class CompanyDtoExtension
    {
        public static Entities.Company ToEntity(this CompanyDto dto)
        {
            return new Entities.Company
            {
                Id = dto.Id,
                Name = dto.Name,
                NIP = dto.NIP,
                REGON = dto.REGON,
                PhoneNumber = dto.PhoneNumber,
                Address = new Entities.CompanyAddress
                {
                    CompanyId = dto.Id,
                    FlatNumber = dto.FlatNumber,
                    HouseNumber = dto.HouseNumber,
                    Street = dto.Street,
                    City = dto.City,
                }
            };
        }
    }
}
