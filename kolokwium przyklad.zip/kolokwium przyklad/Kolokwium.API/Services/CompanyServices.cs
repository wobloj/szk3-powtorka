﻿using Kolokwium.API.Dto;
using Kolokwium.API.Entities;
using Kolokwium.API.Extensions;
using Kolokwium.API.ServiceBusPublisher;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace Kolokwium.API.Services
{
    public class CompanyServices
    {
        private CompanyDbContext _context;
        private static string conncetionStringSb = @"Endpoint=sb://szkolenietechniczne.servicebus.windows.net/;SharedAccessKeyName=country;SharedAccessKey=7mJtFANhxaVWTrpx7Yk80oWc71SMMCMK/+ASbMRPcWA=;EntityPath=country-new";
        private static string queueName = "country-new";
        private readonly ServiceBusQueueSender _sbPublisher;

        public CompanyServices(CompanyDbContext context)
        {
            _sbPublisher = new ServiceBusQueueSender(conncetionStringSb, queueName);
            _context = context;
        }

        public async Task<CompanyDto> GetById(int id)
        {
            var company = await _context
                .Set<Company>()
                .Include(x => x.Address)
                .AsNoTracking()
                .Where(x => x.Id!.Equals(id))
                .SingleOrDefaultAsync();

            return company == null ? new CompanyDto() : company.ToDto();
        }

        public async Task<IEnumerable<CompanyDto>> Get()
        {
            var companies = await _context
                .Set<Company>()
                .Include(x => x.Address)
                .AsNoTracking()
                .ToListAsync();

            return companies.Select(e => e.ToDto());
        }

        public async Task Delete(int id)
        {
            var entity = await _context
                .Set<Entities.Company>()
                .SingleOrDefaultAsync(x => x.Id!.Equals(id));

            if(entity == null)
            {
                return;
            }

            _context.Set<Entities.Company>().Remove(entity);

            await _context.SaveChangesAsync();
        }

        public async Task<int> Create(CompanyDto dto)
        {
            var entity = dto.ToEntity();
            _context
                .Set<Entities.Company>()
                .Add(entity);

            await _context.SaveChangesAsync();

            var messageContent = JsonConvert.SerializeObject(entity);
            await _sbPublisher.SendAsync(messageContent);

            return dto.Id;
        }

        public async Task<int> Update(CompanyDto dto)
        {
            var entityBeforeUpdate = await GetById(dto.Id);

            if(entityBeforeUpdate == null)
            {
                return 0;
            }

            var newEntity = dto.ToEntity();
            _context.Entry(newEntity).State = EntityState.Modified;

            await _context.SaveChangesAsync();

            return dto.Id;
        }
    }
}
