﻿using Kolokwium.API.Entities;
using Microsoft.EntityFrameworkCore;

namespace Kolokwium.API
{
    public class CompanyDbContext : DbContext
    {
        private IConfiguration _configuration { get; }

        public DbSet<Company> Companies { get; set; } = null!;
        public DbSet<CompanyAddress> CompanyAddresses { get; set; } = null!;

        public CompanyDbContext(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) 
        {
            optionsBuilder.UseSqlServer(@"server = 10.200.2.28; Database = kol-szk-w65555; User Id = stud; Password = wsiz",
                x => x.MigrationsHistoryTable("__EfMigrationHistory", "Company"));

            optionsBuilder.LogTo(x => System.Diagnostics.Debug.WriteLine(x));
        }
    }
}
