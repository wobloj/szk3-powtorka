﻿using Azure.Messaging.ServiceBus;

namespace Kolokwium.API.ServiceBusPublisher
{
    public class ServiceBusQueueSender
    {
        private readonly string connectionString;
        private readonly string queueName;
        private ServiceBusClient client;
        private ServiceBusSender sender;

        public ServiceBusQueueSender(string connectionString, string queueName)
        {
            this.connectionString = connectionString;
            this.queueName = queueName;
            client = new ServiceBusClient(connectionString);
            sender = client.CreateSender(queueName);
        }

        public async Task SendAsync(string messageContent)
        {
            ServiceBusMessage message = new ServiceBusMessage(messageContent);

            await sender.SendMessageAsync(message);
        }
    }
}
