﻿using Kolokwium.API.Dto;
using Kolokwium.API.Services;
using Microsoft.AspNetCore.Mvc;

namespace Kolokwium.API.Controllers
{
    [Route("/company")]
    public class CompanyController : Controller
    {
        private readonly CompanyServices _companyService;
        
        public CompanyController(CompanyServices companyService)
        {
            _companyService = companyService;
        }

        //[HttpGet("companies")]
        //public async Task<IEnumerable>

        [HttpGet("companies/{id}")]
        public async Task<IActionResult> ReadById(int id)
        {
            var companyDto = await _companyService.GetById(id);

            if(companyDto == null)
            {
                return NotFound();
            }

            return Ok(companyDto);
        }

        [HttpPost("company")]
        public async Task<IActionResult> Create([FromBody] CompanyDto dto)
        {
            if(ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var operationResult = await _companyService.Create(dto);

            return Ok(operationResult);
        }
    }
}
